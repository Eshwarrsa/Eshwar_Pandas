# Eshwar-Pandas

A minimal wrapper around pandas to easily load CSV files, preview them, and inspect column data types.

## Installation

```bash
pip install eshwar-pandas
